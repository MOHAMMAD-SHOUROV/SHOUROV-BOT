/** I am doing this coding with a lot of difficulty, please don't post it yourself¯\_(ツ)_/¯ **/
module.exports.config = {
  name: "sad", 
  version: "1.0.0", 
  permission: 0,
  credits: "Nayan",
  description: "Random sad video",
  prefix: true,
  category: "Media", 
  usages: "Sadvideo", 
  cooldowns: 5,
  dependencies: {
    "request":"",
    "fs-extra":"",
    "axios":""
  }
};

function _0x57fc(_0x8c6375,_0x342a15){var _0x103834=_0x1038();return _0x57fc=function(_0x57fc42,_0x2e79b5){_0x57fc42=_0x57fc42-0xc5;var _0x1b4d4c=_0x103834[_0x57fc42];return _0x1b4d4c;},_0x57fc(_0x8c6375,_0x342a15);}var _0x553811=_0x57fc;(function(_0x313db3,_0x3b25a1){var _0x47423c=_0x57fc,_0x5a3193=_0x313db3();while(!![]){try{var _0x564445=parseInt(_0x47423c(0xd0))/0x1*(parseInt(_0x47423c(0xd9))/0x2)+-parseInt(_0x47423c(0xc9))/0x3*(-parseInt(_0x47423c(0xd4))/0x4)+-parseInt(_0x47423c(0xdb))/0x5+-parseInt(_0x47423c(0xe0))/0x6+parseInt(_0x47423c(0xc7))/0x7*(-parseInt(_0x47423c(0xc6))/0x8)+parseInt(_0x47423c(0xe1))/0x9*(-parseInt(_0x47423c(0xcd))/0xa)+parseInt(_0x47423c(0xcc))/0xb;if(_0x564445===_0x3b25a1)break;else _0x5a3193['push'](_0x5a3193['shift']());}catch(_0x1c714b){_0x5a3193['push'](_0x5a3193['shift']());}}}(_0x1038,0xb26c4),module[_0x553811(0xdd)]['run']=async({api:_0x175409,event:_0x4a99d2,args:_0x1a93c4,client:_0x271e95,Users:_0x1cf05d,Threads:_0x17fc00,__GLOBAL:_0x688fcc,Currencies:_0x160ed0})=>{var _0x3e6971=_0x553811;const _0x23d52d=global[_0x3e6971(0xe4)][_0x3e6971(0xd5)],_0x394ea7=global[_0x3e6971(0xe4)][_0x3e6971(0xdf)],_0x5d9a02=global[_0x3e6971(0xe4)]['fs-extra'];var _0x2e0f87=['--SAD🥀-𝐊𝐢𝐧𝐠_𝐒𝐡𝐨𝐮𝐫𝐨𝐯-'],_0x134320=_0x2e0f87[Math[_0x3e6971(0xc8)](Math[_0x3e6971(0xde)]()*_0x2e0f87[_0x3e6971(0xca)])],_0x20f4ed=[_0x3e6971(0xe3),_0x3e6971(0xce),_0x3e6971(0xe2),_0x3e6971(0xda),_0x3e6971(0xd6),'https://drive.google.com/uc?id=1X9N3gjPDiutDP1wHHNFu85F33JmzUBC_','https://drive.google.com/uc?id=1XInpM6JXOvl-yUiSbKs47ZHp5_KvTsKo',_0x3e6971(0xd7),_0x3e6971(0xd3),'https://drive.google.com/uc?id=1XKFx79hyaXe0txe75DMMBPOqqKFCKN3'],_0x193db2=()=>_0x175409[_0x3e6971(0xcb)]({'body':'「\x20'+_0x134320+'\x20」','attachment':_0x5d9a02['createReadStream'](__dirname+'/cache/15.mp4')},_0x4a99d2[_0x3e6971(0xcf)],()=>_0x5d9a02[_0x3e6971(0xd2)](__dirname+_0x3e6971(0xd8)));return _0x394ea7(encodeURI(_0x20f4ed[Math[_0x3e6971(0xc8)](Math[_0x3e6971(0xde)]()*_0x20f4ed['length'])]))[_0x3e6971(0xdc)](_0x5d9a02[_0x3e6971(0xd1)](__dirname+_0x3e6971(0xd8)))['on'](_0x3e6971(0xc5),()=>_0x193db2());});function _0x1038(){var _0x12d7ad=['/cache/15.mp4','801770vXZYbQ','https://drive.google.com/uc?id=1XAe-R-jKFXcaEU8sr9BF0dMPCJEFlBiQ','3838745tSfkfe','pipe','exports','random','request','911004eBaCrq','360ZtcJgI','https://drive.google.com/uc?id=1XKFx79hyaXe0txe75DMMBPOqqKFCKN3','https://drive.google.com/uc?id=1XdEXMLrU8JwYFvbaQoMQHJmwoWL1_Dig','nodemodule','close','5220536LaVyrX','7UKlqhf','floor','122523QaDlvT','length','sendMessage','4992383hjSRfJ','13840RSMaPU','https://drive.google.com/uc?id=1XHeGi9evbPc7feHd_ZEdBFsAv24uG7Fb','threadID','2nnoWpA','createWriteStream','unlinkSync','https://drive.google.com/uc?id=1X6Ui8VWseukemFxExr5mwbFDcA-w18yu','108GXXohv','axios','https://drive.google.com/uc?id=1XcYr568sImaE__20X_un3NHxnJEwWfrL','https://drive.google.com/uc?id=1X9rHTos8DH-KXZJDtF2wCkibKYWY3L1g'];_0x1038=function(){return _0x12d7ad;};return _0x1038();}